package com.example.WeatherDataRetrieval.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class WeatherDataRetrievalService {
    private final RestTemplate restTemplate;

    @Autowired
    public WeatherDataRetrievalService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getWeatherDataForLocation(String locationId) {
        // Communicate with Location Management Microservice to get location details
        String locationDetailsUrl = "http://localhost:9001/locations/" + locationId;

        String locationDetails = restTemplate.getForObject(locationDetailsUrl, String.class);

        // Use location details to fetch weather data from external source or database
        // Replace this with your actual logic for fetching weather data

        return "Weather data for location: " + locationDetails;
    }
}
