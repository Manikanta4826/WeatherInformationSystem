package com.example.LocationManagement.controller;

import com.example.LocationManagement.entity.LocationEntity;
import com.example.LocationManagement.service.LocationManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/locations")
public class LocationManagementController {
    private final LocationManagementService locationService;

    @Autowired
    public LocationManagementController(LocationManagementService locationService) {
        this.locationService = locationService;
    }

    @GetMapping
    public ResponseEntity<List<LocationEntity>> getLocations() {
        List<LocationEntity> locations = locationService.getAllLocations();
        return ResponseEntity.ok(locations);
    }

    @GetMapping("/{locationId}")
    public ResponseEntity<LocationEntity> getLocationById(@PathVariable String locationId) {
        LocationEntity location = locationService.getLocationById(locationId);
        if (location != null) {
            return ResponseEntity.ok(location);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/add")
    public ResponseEntity<String> addLocation(@RequestBody LocationEntity location) {
        String locationId = locationService.addLocation(location);
        return ResponseEntity.ok("Location added with ID: " + locationId);
    }

    @PutMapping("/{locationId}")
    public ResponseEntity<String> updateLocation(@PathVariable String locationId, @RequestBody LocationEntity location) {
        boolean updated = locationService.updateLocation(locationId, location);
        if (updated) {
            return ResponseEntity.ok("Location updated successfully.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{locationId}")
    public ResponseEntity<String> deleteLocation(@PathVariable String locationId) {
        boolean deleted = locationService.deleteLocation(locationId);
        if (deleted) {
            return ResponseEntity.ok("Location deleted successfully.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
