package com.example.LocationManagement.repository;

import com.example.LocationManagement.entity.LocationEntity;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface LocationRepository extends MongoRepository<LocationEntity, String> {
    // Repository methods
}
