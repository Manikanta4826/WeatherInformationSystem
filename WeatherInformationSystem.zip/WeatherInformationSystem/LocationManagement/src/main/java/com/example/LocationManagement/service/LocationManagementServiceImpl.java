package com.example.LocationManagement.service;

import com.example.LocationManagement.entity.LocationEntity;
import com.example.LocationManagement.repository.LocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LocationManagementServiceImpl implements LocationManagementService {
    private final LocationRepository locationRepository;

    @Autowired
    public LocationManagementServiceImpl(LocationRepository locationRepository) {
        this.locationRepository = locationRepository;
    }

    @Override
    public List<LocationEntity> getAllLocations() {
        return locationRepository.findAll();
    }

    @Override
    public LocationEntity getLocationById(String id) {
        Optional<LocationEntity> locationOptional = locationRepository.findById(id);
        return locationOptional.orElse(null);
    }

    @Override
    public String addLocation(LocationEntity location) {
        LocationEntity savedLocation = locationRepository.save(location);
        return savedLocation.getId();
    }

    @Override
    public boolean updateLocation(String id, LocationEntity location) {
        if (locationRepository.existsById(id)) {
            location.setId(id);
            locationRepository.save(location);
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteLocation(String id) {
        if (locationRepository.existsById(id)) {
            locationRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
