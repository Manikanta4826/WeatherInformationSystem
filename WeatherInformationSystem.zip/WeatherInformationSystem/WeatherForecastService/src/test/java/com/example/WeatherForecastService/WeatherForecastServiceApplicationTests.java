package com.example.WeatherForecastService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherForecastServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
