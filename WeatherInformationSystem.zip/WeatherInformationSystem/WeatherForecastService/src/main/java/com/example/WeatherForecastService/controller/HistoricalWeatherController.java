package com.example.WeatherForecastService.controller;

import com.example.WeatherForecastService.entity.HistoricalWeather;
import com.example.WeatherForecastService.service.HistoricalWeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/historical-weather")
public class HistoricalWeatherController {
    private final HistoricalWeatherService weatherService;

    @Autowired
    public HistoricalWeatherController(HistoricalWeatherService weatherService) {
        this.weatherService = weatherService;
    }

    @PostMapping("/add")
    public ResponseEntity<String> addHistoricalWeather(@RequestBody HistoricalWeather weatherData) {
        weatherService.saveHistoricalWeather(weatherData);
        return ResponseEntity.status(HttpStatus.CREATED).body("Historical weather data added successfully.");
    }

    @GetMapping("/location")
    public ResponseEntity<List<HistoricalWeather>> getWeatherByLocationAndDate(
            @RequestParam String location,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<HistoricalWeather> weatherData = weatherService.getWeatherByLocationAndDate(location, date);
        if (weatherData.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(weatherData);
    }

    @GetMapping("/all")
    public ResponseEntity<List<HistoricalWeather>> getAllWeatherData() {
        List<HistoricalWeather> weatherData = weatherService.getAllWeatherData();
        if (weatherData.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(weatherData);
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateHistoricalWeather(
            @PathVariable Long id,
            @RequestBody HistoricalWeather weatherData) {
        return weatherService.updateHistoricalWeather(id, weatherData);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteHistoricalWeather(@PathVariable Long id) {
        return weatherService.deleteHistoricalWeather(id);
    }
}
